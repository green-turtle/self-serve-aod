#
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

from __future__ import print_function

import base64
import logging
import json
import gzip
import io
import dateutil.parser

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    logger.info('<<selfserve-firehose>> event = ' + json.dumps(event))
    output = []
    
    records_processed = 0
    records_dropped = 0
    record_id_suffix=0

    for record in event['records']:
        output_payload_str = ""
        
        logger.info('<<selfserve-firehose>> input record = ' + json.dumps(record))
        
        # decode and unzip the data
        data = base64.b64decode(record['data'])
        striodata = io.BytesIO(data)
        with gzip.GzipFile(fileobj=striodata, mode='r') as f:
            data = json.loads(f.read())

        logger.info("decoded payload = {}".format(str(data)))

        payload_str = json.dumps(data)
        logger.info("payload_str = {}".format(payload_str))
        payload_dict = json.loads(payload_str)

        # skip CloudWatch Logs control messages
        message_type = get_attribute_safely("messageType", payload_dict)
        if not message_type:
            logger.info('<<selfserve-firehose>> DROPPING record: no messageType value')
            records_dropped += 1
            output_record = {
                'recordId': record['recordId'],
                'result': 'Dropped',
                'data': record['data']
            }
            output.append(output_record)
            continue

        if message_type == "CONTROL_MESSAGE":
            logger.info('<<selfserve-firehose>> DROPPING record: skipping CONTROL_MESSAGE')
            records_dropped += 1
            output_record = {
                'recordId': record['recordId'],
                'result': 'Dropped',
                'data': record['data']
            }
            output.append(output_record)
            continue

        log_events = payload_dict.get("logEvents")
        if not log_events:
            logger.info('<<selfserve-firehose>> DROPPING record: can\'t find logEvents in payload')
            records_dropped += 1
            output_record = {
                'recordId': record['recordId'],
                'result': 'Dropped',
                'data': record['data']
            }
            output.append(output_record)
            continue
        
        if len(log_events) == 0:
            logger.info('<<selfserve-firehose>> DROPPING record: logEvents in payload is empty')
            records_dropped += 1
            output_record = {
                'recordId': record['recordId'],
                'result': 'Dropped',
                'data': record['data']
            }
            output.append(output_record)
            continue
        
        message = log_events[0].get("message")
        if not message:
            logger.info('<<selfserve-firehose>> DROPPING record: can\'t find message in payload')
            records_dropped += 1
            output_record = {
                'recordId': record['recordId'],
                'result': 'Dropped',
                'data': record['data']
            }
            output.append(output_record)
            continue
            
        message_dict = json.loads(message)

        logger.info('<<selfserve-firehose>> PROCESSING record: input message={}'.format(json.dumps(message_dict)))

        # convert any slot values into proper columns
        if message_dict.get('slots', None) is not None:
            for slot_name in message_dict['slots']:
                message_dict['slot_' + slot_name] = message_dict['slots'][slot_name]
            del message_dict['slots']

        # convert sessions attributes into proper columns
        if message_dict.get('sessionAttributes', None) is not None:
            for attribute_name in message_dict['sessionAttributes']:
                message_dict['attribute_' + attribute_name] = message_dict['sessionAttributes'][attribute_name]
            del message_dict['sessionAttributes']

        # convert request attributes into proper columns
        if message_dict.get('requestAttributes', None) is not None:
            for attribute_name in message_dict['requestAttributes']:
                message_dict['request_' + attribute_name] = message_dict['requestAttributes'][attribute_name]
            del message_dict['requestAttributes']

        # convert alternative intents into columns
        if message_dict.get('alternativeIntents', None) is not None:
            count = 0
            alternative_intents = message_dict['alternativeIntents']
            for alt in alternative_intents:
                confidence = alt.get('nluIntentConfidence', None)
                if confidence is not None:
                    if float(confidence) > 0.0:
                        count += 1
                        message_dict['alternativeIntent_' + str(count) + '_Name'] = alt.get('name')
                        message_dict['alternativeIntent_' + str(count) + '_Confidence'] = float(alt.get('nluIntentConfidence', '0.0'))
                        for key in alt.get('slots', {}):
                            if alt['slots'].get(key, None) is not None:
                                message_dict['alternativeIntent_' + str(count) + '_Slot_' + key] = alt['slots'][key]
            del message_dict['alternativeIntents']
            
        # convert sentiment scores to columns
        if message_dict.get('sentimentResponse', None):
            if message_dict['sentimentResponse'].get('sentimentLabel', None):
                message_dict['sentimentLabel'] = message_dict['sentimentResponse']['sentimentLabel']
            if message_dict['sentimentResponse'].get('sentimentScore', None):
                # expecting string such as '{Positive: 3.634553E-4,Negative: 0.99010056,Neutral: 0.009535047,Mixed: 9.968452E-7}'
                scores = message_dict['sentimentResponse']['sentimentScore'].translate({ord(i): None for i in '{}'})
                scores = scores.split(',')
                for score in scores:
                    values = score.split(': ')
                    if len(values) == 2:
                        message_dict['sentimentScore'+values[0]] = float(values[1])
            del message_dict['sentimentResponse']
            
        # convert timestamp into convenient date forms
        if message_dict.get('timestamp', None):
            dt = dateutil.parser.isoparse(message_dict['timestamp'])
            if dt:
                message_dict['message_year'] = str(dt.year)
                message_dict['message_month'] = "{:d}-{:02d}".format(dt.year, dt.month)
                message_dict['message_day'] = "{:d}-{:02d}-{:02d}".format(dt.year, dt.month, dt.day)
                message_dict['message_datetime'] = "{:d}-{:02d}-{:02d}T{:02d}:{:02d}:{:02d}".format(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
                message_dict['message_timezone'] = "UTC"        

        # remove response cards
        if message_dict.get('responseCard', None) is not None:
            del message_dict['responseCard']

        logger.info('<<selfserve-firehose>> PROCESSING record: output message={}'.format(json.dumps(message_dict)))
        output_payload_str += json.dumps(message_dict) + '\n'
        
        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': base64.b64encode(output_payload_str.encode('ascii')).decode('ascii')
        }
        logger.info("output_record-data type = {}".format(str(type(output_record['data']))))
        output.append(output_record)
        records_processed += 1

    logger.info('Successfully processed {} records, dropped {} records.'.format(records_processed, records_dropped))
    logger.info("output records = {}".format(json.dumps(output)))
    return {'records': output}


def get_attribute_safely(attribute_path, data_dict):
    return_value = None
    sub_dict = data_dict
    path = attribute_path.split(":")
    if len(path) > 0:
        for item in path:
            if sub_dict.get(item):
                next_item = sub_dict[item]
                #logger.info("get_attribute_safely: found path {} in {}, value={}, type={}".format(
                #    item, sub_dict, json.dumps(next_item), str(type(next_item))))
                if str(type(next_item)) == "<type 'unicode'>":
                    return next_item
                sub_dict = next_item
                return_value = next_item
            else:
                # can't walk the whole path
                return None

    return return_value


